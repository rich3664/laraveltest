# Release Notes

## [Unreleased](https://github.com/laravel/sail/compare/v1.x.x...1.x)


## [v1.0.0 (2020-??-??)](https://github.com/laravel/sail/compare/v0.0.1...v1.0.0)

Initial stable release.
